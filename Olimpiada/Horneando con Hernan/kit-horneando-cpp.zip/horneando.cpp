void alarma();

void inicializar(int temperaturaMaxima) {
    // Acá tenés que hacer la inicialización
}

void cambiarTemperatura(int nuevaTemperatura) {
    // Acá tenés que decidir si hacer sonar la alarma o no
    alarma();
}
