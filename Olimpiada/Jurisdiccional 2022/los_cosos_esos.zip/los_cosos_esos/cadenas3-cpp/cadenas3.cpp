#include <string>
#include <vector>

using namespace std;

vector<int> cadenas(vector<int> &a) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
