#include <string>
#include <vector>

using namespace std;

int impares(vector<vector<int>> &subordinados) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
