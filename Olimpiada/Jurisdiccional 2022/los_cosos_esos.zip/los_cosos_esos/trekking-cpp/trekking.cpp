#include <string>
#include <vector>

using namespace std;

long long trekking(vector<vector<int>> &mapa) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
