#include <string>
#include <vector>

using namespace std;

int envido(int numero1, string &palo1, int numero2, string &palo2, int numero3, string &palo3) {
    // AQUI SE DEBE IMPLEMENTAR LA SOLUCION
}
