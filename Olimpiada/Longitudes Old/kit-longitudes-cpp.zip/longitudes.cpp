#include <vector>
#include <string>

using namespace std;

vector<int> dameLongitudes(vector<string> v)
{
    // Aqui se debe implementar la solucion
}
