#include <vector>
#include <string>

using namespace std;

void duplilong(vector<string> &palabras, int K, vector<int> & longitudes)
{
    // Aqui se debe implementar la solucion
}
